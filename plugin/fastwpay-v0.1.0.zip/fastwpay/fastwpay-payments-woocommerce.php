<?php
/**
 * Plugin Name: fastwpay Payments Gateway
 * Plugin URI: https://fastwpay.com
 * Author: Jesus Farias
 * Author URI: https://fastwpay.com
 * Description: Payments Gateway for fastwpay.
 * Version: 0.1.0
 * License: GPL2
 * License URL: http://www.gnu.org/licenses/gpl-2.0.txt
 * text-domain: fastwpay-payments-woo
 * 
 * Class WC_Gateway_fastwpay file.
 *
 * @package WooCommerce\fastwpay
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
define('DocFastWpay', plugin_dir_path(__FILE__));
define('ARCFastWpay', plugin_dir_url(__FILE__));
define('pagePayment', 'FastWpay');


if ( ! in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) return;

add_action( 'plugins_loaded', 'fastwpay_payment_init', 11 );
add_filter( 'woocommerce_currencies', 'techiepress_add_ugx_currencies' );
add_filter( 'woocommerce_currency_symbol', 'techiepress_add_ugx_currencies_symbol', 10, 2 );
add_filter( 'woocommerce_payment_gateways', 'add_to_woo_fastwpay_payment_gateway');

function fastwpay_payment_init() {
    if( class_exists( 'WC_Payment_Gateway' ) ) {
		require_once plugin_dir_path( __FILE__ ) . '/includes/class-wc-payment-gateway-fastwpay.php';
		require_once plugin_dir_path( __FILE__ ) . '/includes/fastwpay-order-statuses.php';
	}
}

function add_to_woo_fastwpay_payment_gateway( $gateways ) {
    $gateways[] = 'WC_Gateway_fastwpay';
    return $gateways;
}

function techiepress_add_ugx_currencies( $currencies ) {
	$currencies['eur'] = __( 'Ugandan Shillings', 'fastwpay-payments-woo' );
	return $currencies;
}

function techiepress_add_ugx_currencies_symbol( $currency_symbol, $currency ) {
	switch ( $currency ) {
		case 'eur': 
			$currency_symbol = 'eur'; 
		break;
	}
	return $currency_symbol;
}


add_filter( 'page_template', 'page_payment_fastwpay' );
function page_payment_fastwpay( $page_template ){

    if ( get_page_template_slug() == 'includes/fastwpay.php' ) {
        $page_template = dirname( __FILE__ ) . '/includes/fastwpay.php';
    }
    return $page_template;
}

    function fastwpay_page_payment(){

    global $wpdb;
    $query = $wpdb->prepare(
            'SELECT ID FROM ' . $wpdb->posts . '
                WHERE post_title = %s
                AND post_type = \'page\'',
            pagePayment
        );
        $wpdb->query( $query );
        if ( $wpdb->num_rows ) {
            $wpdb->update($wpdb->posts,
            array('post_status'=> 'publish'),
            array('post_title' => pagePayment,'post_type'=>'page'));
        } else {
        $new_page_id = wp_insert_post( array(
                'post_title'     => pagePayment ,
                'post_type'      => 'page',
                'post_name'      => 'FastWpay',
                'post_status'    => 'publish',
                'post_author'    => 1,
                'menu_order'     => 8,
                'page_template'  => 'includes/fastwpay.php'
            ) );
        $post_id = wp_insert_post($new_page_id);
    }
}


register_activation_hook(__FILE__, 'fastwpay_page_payment');

add_filter( 'theme_page_templates', 'fastwpay_add_template_to_select', 10, 5 );
function fastwpay_add_template_to_select( $post_templates, $wp_theme, $post, $post_type ) {

    // Add custom template named template-custom.php to select dropdown
    $post_templates['includes/fastwpay.php'] = __('fastwpay');

    return $post_templates;
}



add_action( 'wp_ajax_redeem_complete', 'fastwpay_redeem_complete');
add_action( 'wp_ajax_nopriv_redeem_complete', 'fastwpay_redeem_complete');
function fastwpay_redeem_complete(){
    if ( isset($_POST['order_id']) && $_POST['order_id'] > 0 ) {
    	try {
	    	$order = wc_get_order($_POST['order_id']);
	        $order->update_status('processing');
	        // $order->update_status('on-hold', 'Esperando el pago');
		  		$order->payment_complete();
		  		$order->reduce_order_stock();
				WC()->cart->empty_cart();
				// wp_safe_redirect( $_POST['thankyour'] );
				echo $_POST['order_id'];
	        die(true);
		    } catch (Exception $e) {
		    	die(false);
		    }
    }else{
    	die(false);
    }
}